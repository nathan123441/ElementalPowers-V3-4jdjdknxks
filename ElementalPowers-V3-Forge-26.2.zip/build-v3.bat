@echo off
echo Elemental Powers V3 - Minecraft 26.2 Forge
echo Requer JDK 25.
java -version
if errorlevel 1 exit /b 1
call gradlew.bat clean build
if errorlevel 1 (
  echo.
  echo A compilacao falhou. Verifique Java 25 e a conexao com os repositorios Maven.
  exit /b 1
)
echo.
echo JAR gerado em build\libs\
pause
