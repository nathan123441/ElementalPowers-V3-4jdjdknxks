@echo off
setlocal
if not exist "%JAVA_HOME%\bin\java.exe" (
  echo JAVA_HOME nao esta configurado. Instale o JDK 25 e configure JAVA_HOME.
  exit /b 1
)
call gradlew.bat clean build
if errorlevel 1 (
  echo.
  echo Falha na compilacao. Veja o erro acima.
  exit /b 1
)
echo.
echo JAR criado em: build\libs\ElementalPowers-Forge-26.2-1.0.0.jar
endlocal
