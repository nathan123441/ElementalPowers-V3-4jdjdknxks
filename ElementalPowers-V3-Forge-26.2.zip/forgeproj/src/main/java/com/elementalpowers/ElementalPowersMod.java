package com.elementalpowers;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

@Mod(ElementalPowersMod.MOD_ID)
public class ElementalPowersMod {
    public static final String MOD_ID = "elementalpowers";
    public static final String VERSION = "26.2";

    private static final Map<UUID, Integer> mana = new HashMap<>();
    private static final Map<UUID, Integer> level = new HashMap<>();
    private static final Map<UUID, Integer> xp = new HashMap<>();

    public ElementalPowersMod() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    public static int getMana(Player p) { return mana.getOrDefault(p.getUUID(), 100); }
    public static int getMaxMana(Player p) { return 100 + (getLevel(p)-1) * 10; }
    public static int getLevel(Player p) { return level.getOrDefault(p.getUUID(), 1); }
    public static int getXp(Player p) { return xp.getOrDefault(p.getUUID(), 0); }

    public static boolean spendMana(Player p, int amount) {
        int m = getMana(p);
        if (m < amount) return false;
        mana.put(p.getUUID(), m - amount);
        return true;
    }

    public static void addXp(Player p, int amount) {
        int v = getXp(p) + amount;
        int need = getLevel(p) * 100;
        while (v >= need) {
            v -= need;
            level.put(p.getUUID(), getLevel(p) + 1);
            mana.put(p.getUUID(), getMaxMana(p));
            p.displayClientMessage(Component.literal("§6Nível elemental aumentado! §eNível " + getLevel(p)), true);
            need = getLevel(p) * 100;
        }
        xp.put(p.getUUID(), v);
    }

    public static void usePower(ServerPlayer p, String element, int attack) {
        int cost = attack == 4 ? 50 : 10 + attack * 5;
        if (!spendMana(p, cost)) {
            p.displayClientMessage(Component.literal("§cMana insuficiente!"), true);
            return;
        }

        Vec3 look = p.getLookAngle().normalize();
        Vec3 origin = p.position().add(0, p.getEyeHeight(), 0);
        var level = p.level();

        for (int i = 1; i <= 14; i++) {
            Vec3 pos = origin.add(look.scale(i * 0.8));
            spawnParticles(level, element, pos);
        }

        AABB box = p.getBoundingBox().inflate(attack == 4 ? 7 : 3.0);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != p && e.isAlive());

        double damage = attack == 4 ? 16 : 5 + attack * 2;
        for (LivingEntity target : targets) {
            Vec3 delta = target.position().subtract(p.position());
            if (delta.lengthSqr() <= 64 || attack == 4) {
                target.hurt(level.damageSources().playerAttack(p), (float) damage);
                if (element.equals("ice")) target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 2));
                if (element.equals("fire")) target.setRemainingFireTicks(80);
                if (element.equals("air")) target.push(look.x * 1.3, 0.7, look.z * 1.3);
            }
        }

        if (element.equals("space") && attack == 3) {
            p.teleportTo(p.getX() + look.x * 8, p.getY(), p.getZ() + look.z * 8);
        }

        addXp(p, attack == 4 ? 30 : 10);
    }

    private static void spawnParticles(net.minecraft.world.level.Level level, String element, Vec3 pos) {
        if (!(level instanceof net.minecraft.server.level.ServerLevel sl)) return;
        var type = switch (element) {
            case "water" -> net.minecraft.core.particles.ParticleTypes.SPLASH;
            case "fire" -> net.minecraft.core.particles.ParticleTypes.FLAME;
            case "earth" -> net.minecraft.core.particles.ParticleTypes.BLOCK;
            case "air" -> net.minecraft.core.particles.ParticleTypes.CLOUD;
            case "ice" -> net.minecraft.core.particles.ParticleTypes.SNOWFLAKE;
            case "amethyst" -> net.minecraft.core.particles.ParticleTypes.END_ROD;
            default -> net.minecraft.core.particles.ParticleTypes.PORTAL;
        };
        sl.sendParticles(type, pos.x, pos.y, pos.z, 4, .15, .15, .15, .03);
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        mana.putIfAbsent(e.getEntity().getUUID(), 100);
        level.putIfAbsent(e.getEntity().getUUID(), 1);
        xp.putIfAbsent(e.getEntity().getUUID(), 0);
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide()) return;
        if (e.player.tickCount % 10 == 0) {
            int m = getMana(e.player);
            mana.put(e.player.getUUID(), Math.min(getMaxMana(e.player), m + 1));
        }
    }
}
