package com.elementalpowers;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ElementalPowersMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ElementalPowersClient {
    public static final KeyMapping WATER = new KeyMapping("key.elementalpowers.water", GLFW.GLFW_KEY_Z, "key.categories.elementalpowers");
    public static final KeyMapping FIRE = new KeyMapping("key.elementalpowers.fire", GLFW.GLFW_KEY_X, "key.categories.elementalpowers");
    public static final KeyMapping EARTH = new KeyMapping("key.elementalpowers.earth", GLFW.GLFW_KEY_C, "key.categories.elementalpowers");
    public static final KeyMapping AIR = new KeyMapping("key.elementalpowers.air", GLFW.GLFW_KEY_V, "key.categories.elementalpowers");
    public static final KeyMapping ICE = new KeyMapping("key.elementalpowers.ice", GLFW.GLFW_KEY_B, "key.categories.elementalpowers");
    public static final KeyMapping AMETHYST = new KeyMapping("key.elementalpowers.amethyst", GLFW.GLFW_KEY_N, "key.categories.elementalpowers");
    public static final KeyMapping SPACE = new KeyMapping("key.elementalpowers.space", GLFW.GLFW_KEY_M, "key.categories.elementalpowers");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(WATER); e.register(FIRE); e.register(EARTH); e.register(AIR);
        e.register(ICE); e.register(AMETHYST); e.register(SPACE);
    }
}
