# Elemental Powers V3 — Minecraft Java 26.2 + Forge 65.0.9

Projeto configurado no formato do MDK oficial do Forge 26.2.

## Elementos definitivos
- Ar
- Fogo
- Terra
- Água
- Gelo
- Ametista
- Espaço

## Requisitos para compilar
- Minecraft Java 26.2
- Forge 65.0.9
- JDK 25
- Gradle 9.5 (ou o Gradle Wrapper)

Forge 26.2 requer Java 25. O MDK oficial usa ForgeGradle 7 e Gradle 9.5.

## Compilar
Windows:
```bat
build-jar.bat
```
Ou:
```bat
gradlew.bat build
```

Linux/macOS:
```bash
./gradlew build
```

## Saída
```text
build/libs/ElementalPowers-Forge-26.2-1.0.0.jar
```

Depois de compilado, esse JAR é o arquivo que deve ser colocado na pasta `mods` de uma instalação Minecraft Java 26.2 com Forge 65.0.9.

> Este ambiente não inclui JDK 25 nem as dependências Forge baixadas, portanto a compilação final precisa ser executada em um ambiente com acesso ao Maven/Gradle.
