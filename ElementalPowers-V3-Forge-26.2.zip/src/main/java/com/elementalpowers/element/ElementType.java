package com.elementalpowers.element;

public enum ElementType {
    AIR("Ar"),
    FIRE("Fogo"),
    EARTH("Terra"),
    WATER("Água"),
    ICE("Gelo"),
    AMETHYST("Ametista"),
    SPACE("Espaço");

    private final String displayName;
    ElementType(String displayName) { this.displayName = displayName; }
    public String displayName() { return displayName; }
}
