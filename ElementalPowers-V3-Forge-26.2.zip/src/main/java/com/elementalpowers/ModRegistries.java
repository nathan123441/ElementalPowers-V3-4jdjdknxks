package com.elementalpowers;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Central V3 registry. */
public final class ModRegistries {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ElementalPowers.MOD_ID);

    public static final RegistryObject<Item> ELEMENTAL_CORE =
            ITEMS.register("elemental_core", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> MANA_CRYSTAL =
            ITEMS.register("mana_crystal", () -> new Item(new Item.Properties()));

    public static final CreativeModeTab TAB = CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.elementalpowers"))
            .icon(() -> ELEMENTAL_CORE.get().getDefaultInstance())
            .displayItems((params, output) -> {
                output.accept(ELEMENTAL_CORE.get());
                output.accept(MANA_CRYSTAL.get());
            }).build();

    private ModRegistries() {}

    public static void register() {
        ITEMS.register(net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext
                .get().getModEventBus());
    }
}
