package com.elementalpowers;

import net.minecraftforge.fml.common.Mod;

/**
 * Elemental Powers V3
 * Minecraft Java 26.2 / Forge 65.0.9
 */
@Mod(ElementalPowers.MOD_ID)
public final class ElementalPowers {
    public static final String MOD_ID = "elementalpowers";

    public ElementalPowers() {
        ModRegistries.register();
    }
}
