ELEMENTAL POWERS V3
Minecraft Java 26.2 + Forge 65.0.9

Elementos definitivos:
- Ar
- Fogo
- Terra
- Agua
- Gelo
- Ametista
- Espaco

Conteudo planejado/estruturado:
- 7 espadas elementais
- 28 pecas de armadura (4 por elemento)
- poderes e supremos por elemento
- particulas e efeitos
- Nucleo Elemental
- Cristal de Mana
- receitas
- modelos/texturas
- aba criativa

COMPILACAO:
1. Instale JDK 25.
2. Abra esta pasta no terminal.
3. Execute: gradlew.bat build
4. O JAR sai em build/libs/.

NOTA:
Este pacote e o codigo-fonte preparado. Um JAR final so deve ser chamado de instalavel depois de uma compilacao bem-sucedida.
